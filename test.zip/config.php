<?php
// config.php - Asosiy konfiguratsiya
session_start();

// Admin parol (o'zingizga mos o'zgartiring)
define('ADMIN_PASSWORD', 'admin123');

// JSON database fayli
define('DB_FILE', 'database.json');
define('DB_AKT_FILE', 'database-akt.json');

// JSON ma'lumotlarini o'qish
function readDB() {
    if (!file_exists(DB_FILE)) {
        $default = [
            'lavozimlar' => [
                ['id' => 1, 'nomi' => 'Menejer', 'savollar_soni' => 0],
                ['id' => 2, 'nomi' => 'Shifokor', 'savollar_soni' => 0],
                ['id' => 3, 'nomi' => 'Rahbar', 'savollar_soni' => 0],
                ['id' => 4, 'nomi' => 'Hamshira', 'savollar_soni' => 0],
                ['id' => 5, 'nomi' => 'Labarant', 'savollar_soni' => 0],
                ['id' => 6, 'nomi' => 'Provizor (ombor mudiri)', 'savollar_soni' => 0],
                ['id' => 7, 'nomi' => 'Administrator', 'savollar_soni' => 0],
                ['id' => 8, 'nomi' => 'Ikkilamchi bo\'g\'in', 'savollar_soni' => 0]
            ],
            'savollar' => [],
            'natijalar' => [],
            'ulashilgan_natijalar' => []
        ];
        file_put_contents(DB_FILE, json_encode($default, JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT));
    }
    return json_decode(file_get_contents(DB_FILE), true);
}

// Umumiy savollar (AKT) ni o'qish
function readAktDB() {
    if (!file_exists(DB_AKT_FILE)) {
        $default = [
            'umumiy_savollar' => []
        ];
        file_put_contents(DB_AKT_FILE, json_encode($default, JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT));
    }
    return json_decode(file_get_contents(DB_AKT_FILE), true);
}

// Umumiy savollarga yozish
function writeAktDB($data) {
    return file_put_contents(DB_AKT_FILE, json_encode($data, JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT));
}

// JSON ga yozish
function writeDB($data) {
    return file_put_contents(DB_FILE, json_encode($data, JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT));
}

// Admin tekshirish
function isAdmin() {
    return isset($_SESSION['admin']) && $_SESSION['admin'] === true;
}

// Login tekshirish
function checkAdmin($password) {
    if ($password === ADMIN_PASSWORD) {
        $_SESSION['admin'] = true;
        return true;
    }
    return false;
}

// Logout
function adminLogout() {
    unset($_SESSION['admin']);
    session_destroy();
}
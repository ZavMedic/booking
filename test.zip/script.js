// script.js - Foydalanuvchi uchun test funksiyalari

let currentTest = {
    fullname: '',
    position: {},
    questions: [],
    answers: [],
    currentQuestionIndex: 0,
    startTime: null,
    timerInterval: null
};

// Lavozimlarni yuklash
async function loadPositions() {
    try {
        const response = await fetch('api.php?action=get_positions');
        const positions = await response.json();
        
        const select = document.getElementById('position');
        if (select) {
            select.innerHTML = '<option value="">-- Lavozimni tanlang --</option>';
            
            // "Barchasi" optionini qo'shish
            let totalQuestions = 0;
            positions.forEach(pos => {
                totalQuestions += pos.savollar_soni;
            });
            
            if (totalQuestions > 0) {
                const allOption = document.createElement('option');
                allOption.value = 'all';
                allOption.textContent = `Barchasi (${totalQuestions} ta savol)`;
                select.appendChild(allOption);
            }
            
            // Har bir lavozimni qo'shish
            positions.forEach(pos => {
                if (pos.savollar_soni > 0) {
                    const option = document.createElement('option');
                    option.value = pos.id;
                    option.textContent = `${pos.nomi} (${pos.savollar_soni} ta savol)`;
                    select.appendChild(option);
                }
            });
        }
    } catch (error) {
        console.error('Xatolik:', error);
        alert('Lavozimlarni yuklashda xatolik yuz berdi!');
    }
}

// Test boshlash formasi
const startForm = document.getElementById('startForm');
if (startForm) {
    startForm.addEventListener('submit', async (e) => {
        e.preventDefault();
        
        const fullname = document.getElementById('fullname').value.trim();
        const positionId = document.getElementById('position').value;
        
        if (!fullname || !positionId) {
            alert('Iltimos, barcha maydonlarni to\'ldiring!');
            return;
        }
        
        // Lavozim ma'lumotlarini olish
        const response = await fetch('api.php?action=get_positions');
        const positions = await response.json();
        
        let position;
        if (positionId === 'all') {
            // "Barchasi" tanlangan
            let totalQuestions = 0;
            positions.forEach(pos => {
                totalQuestions += pos.savollar_soni;
            });
            
            position = {
                id: 'all',
                nomi: 'Barchasi',
                savollar_soni: totalQuestions
            };
        } else {
            position = positions.find(p => p.id == positionId);
        }
        
        if (!position || position.savollar_soni === 0) {
            alert('Bu lavozim uchun savollar mavjud emas!');
            return;
        }
        
        // Test ma'lumotlarini saqlash
        sessionStorage.setItem('testData', JSON.stringify({
            fullname: fullname,
            position: position
        }));
        
        // Test sahifasiga o'tish
        window.location.href = 'test.php';
    });
}

// Testni boshlash
async function initTest() {
    const testData = JSON.parse(sessionStorage.getItem('testData'));
    
    if (!testData) {
        window.location.href = 'index.php';
        return;
    }
    
    currentTest.fullname = testData.fullname;
    currentTest.position = testData.position;
    
    // Foydalanuvchi ma'lumotlarini ko'rsatish
    const userInfo = document.getElementById('userInfo');
    if (userInfo) {
        userInfo.innerHTML = `
            <strong>👤 ${currentTest.fullname}</strong> | 
            <strong>💼 ${currentTest.position.nomi}</strong>
        `;
    }
    
    // Savollarni yuklash
    try {
        let positionQuestions = [];
        let aktQuestions = [];
        
        if (currentTest.position.id === 'all') {
            // Barchasi tanlangan - barcha lavozim savollari
            const response = await fetch(`api.php?action=get_all_questions`);
            let allQuestions = await response.json();
            allQuestions = allQuestions.sort(() => Math.random() - 0.5);
            
            // 10 ta lavozim savollaridan
            positionQuestions = allQuestions.slice(0, 10);
        } else {
            // Bitta lavozim uchun savollar
            const response = await fetch(`api.php?action=get_questions&position_id=${currentTest.position.id}`);
            let questions = await response.json();
            
            // Maximum 10 ta olamiz
            positionQuestions = questions.slice(0, 10);
        }
        
        // Umumiy savollarni yuklash (AKT)
        const aktResponse = await fetch('api.php?action=get_akt_questions');
        const allAktQuestions = await aktResponse.json();
        
        // Necha ta umumiy savol kerakligini hisoblash
        const neededAktCount = 20 - positionQuestions.length;
        
        if (neededAktCount > 0 && allAktQuestions.length > 0) {
            // Random umumiy savollarni tanlash
            const shuffledAkt = allAktQuestions.sort(() => Math.random() - 0.5);
            aktQuestions = shuffledAkt.slice(0, neededAktCount);
        }
        
        // Barcha savollarni birlashtirish va aralashtrish
        const allQuestions = [...positionQuestions, ...aktQuestions];
        currentTest.questions = allQuestions.sort(() => Math.random() - 0.5);
        
        // Har bir savolning variantlarini aralashtirish
        currentTest.questions = currentTest.questions.map(question => {
            if (question.options) {
                // Options allaqachon bor
                return question;
            } else {
                // Options yaratish kerak
                const options = [
                    {key: 'a', text: question.variant_a},
                    {key: 'b', text: question.variant_b},
                    {key: 'c', text: question.variant_c},
                    {key: 'd', text: question.variant_d}
                ];
                const shuffled = options.sort(() => Math.random() - 0.5);
                return {...question, options: shuffled};
            }
        });
        
        if (currentTest.questions.length === 0) {
            alert('Savollar topilmadi!');
            window.location.href = 'index.php';
            return;
        }
        
        // Javoblar massivini yaratish
        currentTest.answers = new Array(currentTest.questions.length).fill(null);
        currentTest.startTime = new Date();
        
        // Timer boshlash
        startTimer();
        
        // Birinchi savolni ko'rsatish
        showQuestion(0);
        
    } catch (error) {
        console.error('Xatolik:', error);
        alert('Savollarni yuklashda xatolik yuz berdi!');
        window.location.href = 'index.php';
    }
}

// Timer
function startTimer() {
    currentTest.timerInterval = setInterval(() => {
        const now = new Date();
        const diff = Math.floor((now - currentTest.startTime) / 1000);
        const minutes = Math.floor(diff / 60);
        const seconds = diff % 60;
        
        const timerEl = document.getElementById('timer');
        if (timerEl) {
            timerEl.textContent = `⏱️ ${pad(minutes)}:${pad(seconds)}`;
        }
    }, 1000);
}

function pad(num) {
    return num.toString().padStart(2, '0');
}

// Savolni ko'rsatish
function showQuestion(index) {
    currentTest.currentQuestionIndex = index;
    const question = currentTest.questions[index];
    
    // Progress bar
    const progress = ((index + 1) / currentTest.questions.length) * 100;
    document.getElementById('progressBar').style.width = progress + '%';
    document.getElementById('currentQuestion').textContent = index + 1;
    document.getElementById('totalQuestions').textContent = currentTest.questions.length;
    
    // Savol matni
    document.getElementById('questionText').textContent = question.savol;
    
    // Variantlar
    const optionsContainer = document.getElementById('optionsContainer');
    optionsContainer.innerHTML = '';
    
    question.options.forEach(option => {
        const optionDiv = document.createElement('div');
        optionDiv.className = 'option';
        optionDiv.textContent = `${option.key.toUpperCase()}) ${option.text}`;
        
        // Avval tanlangan javobni ko'rsatish
        if (currentTest.answers[index] === option.key) {
            optionDiv.classList.add('selected');
        }
        
        optionDiv.addEventListener('click', () => {
            // Barcha variantlardan 'selected' klassini olib tashlash
            optionsContainer.querySelectorAll('.option').forEach(opt => {
                opt.classList.remove('selected');
            });
            
            // Tanlangan variantga 'selected' klassini qo'shish
            optionDiv.classList.add('selected');
            
            // Javobni saqlash
            currentTest.answers[index] = option.key;
        });
        
        optionsContainer.appendChild(optionDiv);
    });
    
    // Navigatsiya tugmalari
    const prevBtn = document.getElementById('prevBtn');
    const nextBtn = document.getElementById('nextBtn');
    const finishBtn = document.getElementById('finishBtn');
    
    if (index === 0) {
        prevBtn.style.display = 'none';
    } else {
        prevBtn.style.display = 'inline-block';
    }
    
    if (index === currentTest.questions.length - 1) {
        nextBtn.style.display = 'none';
        finishBtn.style.display = 'inline-block';
    } else {
        nextBtn.style.display = 'inline-block';
        finishBtn.style.display = 'none';
    }
}

// Navigatsiya
document.getElementById('prevBtn')?.addEventListener('click', () => {
    if (currentTest.currentQuestionIndex > 0) {
        showQuestion(currentTest.currentQuestionIndex - 1);
    }
});

document.getElementById('nextBtn')?.addEventListener('click', () => {
    if (currentTest.currentQuestionIndex < currentTest.questions.length - 1) {
        showQuestion(currentTest.currentQuestionIndex + 1);
    }
});

// Testni yakunlash
document.getElementById('finishBtn')?.addEventListener('click', async () => {
    // Barcha savollarga javob berilganligini tekshirish
    const unanswered = currentTest.answers.filter(a => a === null).length;
    
    if (unanswered > 0) {
        if (!confirm(`${unanswered} ta savolga javob berilmadi. Baribir yakunlaysizmi?`)) {
            return;
        }
    }
    
    // Timerni to'xtatish
    clearInterval(currentTest.timerInterval);
    
    // Natijalarni hisoblash
    let correctAnswers = 0;
    currentTest.questions.forEach((question, index) => {
        if (currentTest.answers[index] === question.togri_javob) {
            correctAnswers++;
        }
    });
    
    const percentage = (correctAnswers / currentTest.questions.length * 100).toFixed(2);
    
    // Vaqtni hisoblash
    const endTime = new Date();
    const timeDiff = Math.floor((endTime - currentTest.startTime) / 1000);
    const minutes = Math.floor(timeDiff / 60);
    const seconds = timeDiff % 60;
    const timeStr = `${pad(minutes)}:${pad(seconds)}`;
    
    // Natijani saqlash
    try {
        await fetch('api.php?action=save_result', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({
                fio: currentTest.fullname,
                lavozim_id: currentTest.position.id,
                lavozim_nomi: currentTest.position.nomi,
                jami_savollar: currentTest.questions.length,
                togri_javoblar: correctAnswers,
                foiz: percentage,
                vaqt: timeStr
            })
        });
    } catch (error) {
        console.error('Natijani saqlashda xatolik:', error);
    }
    
    // Natijani ko'rsatish
    showResult(correctAnswers, currentTest.questions.length, percentage, timeStr);
});

// Natijani ko'rsatish
function showResult(correct, total, percentage, time) {
    document.getElementById('testContainer').style.display = 'none';
    document.getElementById('resultContainer').style.display = 'block';
    
    // Baholash
    let grade = '';
    let gradeColor = '';
    
    if (percentage >= 90) {
        grade = 'A\'LO';
        gradeColor = '#28a745';
    } else if (percentage >= 80) {
        grade = 'YAXSHI';
        gradeColor = '#17a2b8';
    } else if (percentage >= 70) {
        grade = 'QONIQARLI';
        gradeColor = '#ffc107';
    } else {
        grade = 'QONIQARSIZ';
        gradeColor = '#dc3545';
    }
    
    document.getElementById('resultTitle').textContent = `🎉 ${grade}!`;
    document.getElementById('resultTitle').style.color = gradeColor;
    
    document.getElementById('resultScore').innerHTML = `
        <div style="font-size: 0.6em; margin-bottom: 10px;">Sizning natijangiz:</div>
        ${percentage}%
        <div style="font-size: 0.5em; margin-top: 10px;">${correct} / ${total} to'g'ri</div>
    `;
    document.getElementById('resultScore').style.background = gradeColor;
    
    const currentDate = new Date();
    document.getElementById('resultDetails').innerHTML = `
        <p><strong>👤 F.I.O:</strong> ${currentTest.fullname}</p>
        <p><strong>💼 Lavozim:</strong> ${currentTest.position.nomi}</p>
        <p><strong>📊 Jami savollar:</strong> ${total} ta</p>
        <p><strong>✅ To'g'ri javoblar:</strong> ${correct} ta</p>
        <p><strong>❌ Noto'g'ri javoblar:</strong> ${total - correct} ta</p>
        <p><strong>📈 Natija:</strong> ${percentage}% (${grade})</p>
        <p><strong>⏱️ Sarflangan vaqt:</strong> ${time}</p>
        <p><strong>📅 Sana:</strong> ${currentDate.toLocaleString('uz-UZ')}</p>
    `;
    
    // Natija ID ni saqlash (ulashish uchun)
    currentTest.savedResultData = {
        fio: currentTest.fullname,
        lavozim_nomi: currentTest.position.nomi,
        jami_savollar: total,
        togri_javoblar: correct,
        foiz: percentage,
        vaqt: time,
        sana: currentDate.toISOString()
    };
    
    // Session storage tozalash
    sessionStorage.removeItem('testData');
}

// Top 5 natijalarni yuklash
async function loadTopResults() {
    try {
        const response = await fetch('api.php?action=get_top_results');
        const topResults = await response.json();
        
        const container = document.getElementById('topResultsList');
        if (!container) return;
        
        if (topResults.length === 0) {
            container.innerHTML = '<p style="text-align: center; color: #666;">Hali natijalar yo\'q</p>';
            return;
        }
        
        let html = '<div class="top-list">';
        topResults.forEach((result, index) => {
            const medal = index === 0 ? '🥇' : index === 1 ? '🥈' : index === 2 ? '🥉' : '🏅';
            const gradeColor = result.foiz >= 90 ? '#28a745' : result.foiz >= 80 ? '#17a2b8' : result.foiz >= 70 ? '#ffc107' : '#dc3545';
            
            html += `
                <div class="top-item" style="display: flex; align-items: center; padding: 15px; background: #f8f9fa; border-radius: 8px; margin-bottom: 10px; border-left: 4px solid ${gradeColor};">
                    <div style="font-size: 2em; margin-right: 15px;">${medal}</div>
                    <div style="flex: 1;">
                        <div style="font-weight: 600; color: #333;">${result.fio}</div>
                        <div style="font-size: 0.9em; color: #666;">${result.lavozim_nomi}</div>
                    </div>
                    <div style="text-align: right;">
                        <div style="font-size: 1.5em; font-weight: bold; color: ${gradeColor};">${r
// Tahlilni ko'rsatish
function showAnalysis() {
    if (!currentTest.questions || currentTest.questions.length === 0) {
        alert('Test ma\'lumotlari topilmadi!');
        return;
    }
    
    // Result container ni yashirish
    document.getElementById('resultContainer').style.display = 'none';
    
    // Analysis container ni ko'rsatish
    document.getElementById('analysisContainer').style.display = 'block';
    
    // Tahlil contentini yaratish
    generateAnalysisContent();
}

// Tahlilni yashirish
function hideAnalysis() {
    document.getElementById('analysisContainer').style.display = 'none';
    document.getElementById('resultContainer').style.display = 'block';
}

// Tahlil contentini yaratish
function generateAnalysisContent() {
    const container = document.getElementById('analysisContent');
    
    // Statistika
    let correctCount = 0;
    let incorrectCount = 0;
    
    currentTest.questions.forEach((question, index) => {
        if (currentTest.answers[index] === question.togri_javob) {
            correctCount++;
        } else {
            incorrectCount++;
        }
    });
    
    const percentage = ((correctCount / currentTest.questions.length) * 100).toFixed(2);
    
    // Summary
    let html = `
        <div class="analysis-summary">
            <h3>📈 Umumiy Ko'rsatkichlar</h3>
            <div class="summary-stats">
                <div class="stat-item">
                    <div class="stat-value">${currentTest.questions.length}</div>
                    <div class="stat-label">Jami Savollar</div>
                </div>
                <div class="stat-item">
                    <div class="stat-value" style="color: #a3ffab;">${correctCount}</div>
                    <div class="stat-label">✅ To'g'ri</div>
                </div>
                <div class="stat-item">
                    <div class="stat-value" style="color: #ffabab;">${incorrectCount}</div>
                    <div class="stat-label">❌ Noto'g'ri</div>
                </div>
                <div class="stat-item">
                    <div class="stat-value">${percentage}%</div>
                    <div class="stat-label">Natija</div>
                </div>
            </div>
        </div>
    `;
    
    // Har bir savol uchun
    currentTest.questions.forEach((question, index) => {
        const userAnswer = currentTest.answers[index];
        const correctAnswer = question.togri_javob;
        const isCorrect = userAnswer === correctAnswer;
        
        html += `
            <div class="analysis-question ${isCorrect ? 'correct' : 'incorrect'}">
                <div class="question-header">
                    <span class="question-number">Savol ${index + 1}</span>
                    <span class="question-status ${isCorrect ? 'status-correct' : 'status-incorrect'}">
                        ${isCorrect ? '✅ To\'g\'ri' : '❌ Noto\'g\'ri'}
                    </span>
                </div>
                
                <div class="question-text">
                    ${question.savol}
                </div>
                
                <div class="answers-list">
        `;
        
        // Variantlarni ko'rsatish
        const allOptions = [
            { key: 'a', text: question.variant_a },
            { key: 'b', text: question.variant_b },
            { key: 'c', text: question.variant_c },
            { key: 'd', text: question.variant_d }
        ];
        
        allOptions.forEach(option => {
            const isUserAnswer = userAnswer === option.key;
            const isCorrectAnswer = correctAnswer === option.key;
            
            let optionClass = '';
            let badge = '';
            
            if (isCorrectAnswer && isUserAnswer) {
                // To'g'ri javob va foydalanuvchi ham shuni tanlagan
                optionClass = 'answer-option correct-answer';
                badge = '<span class="answer-badge badge-correct">✅ To\'g\'ri javob (Sizning javobingiz)</span>';
            } else if (isCorrectAnswer) {
                // To'g'ri javob
                optionClass = 'answer-option correct-answer';
                badge = '<span class="answer-badge badge-correct">✅ To\'g\'ri javob</span>';
            } else if (isUserAnswer) {
                // Foydalanuvchining noto'g'ri javobi
                optionClass = 'answer-option wrong-answer';
                badge = '<span class="answer-badge badge-wrong">❌ Sizning javobingiz</span>';
            } else {
                // Oddiy variant
                optionClass = 'answer-option';
            }
            
            html += `
                <div class="${optionClass}">
                    <span class="answer-label">${option.key.toUpperCase()})</span>
                    <span class="answer-text">${option.text}</span>
                    ${badge}
                </div>
            `;
        });
        
        // Agar javob berilmagan bo'lsa
        if (!userAnswer) {
            html += `
                <div class="answer-option wrong-answer">
                    <span class="answer-text" style="color: #dc3545; font-weight: 600;">
                        ⚠️ Javob berilmagan
                    </span>
                </div>
            `;
        }
        
        html += `
                </div>
            </div>
        `;
    });
    
    container.innerHTML = html;
    
    // Sahifani tepaga scroll qilish
    window.scrollTo(0, 0);
}
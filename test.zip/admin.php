<?php 
require_once 'config.php';

// Logout
if (isset($_GET['logout'])) {
    adminLogout();
    header('Location: admin.php');
    exit;
}

// Login
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['login'])) {
    if (checkAdmin($_POST['password'])) {
        header('Location: admin.php');
        exit;
    } else {
        $error = "Parol noto'g'ri!";
    }
}

// Admin panel
if (!isAdmin()) {
?>
<!DOCTYPE html>
<html lang="uz">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Login</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <div class="container">
        <div class="login-box">
            <h2>🔐 Administrator Kirishi</h2>
            <?php if (isset($error)): ?>
                <div class="alert alert-error"><?php echo $error; ?></div>
            <?php endif; ?>
            <form method="POST" class="test-form">
                <div class="form-group">
                    <label>Parol:</label>
                    <input type="password" name="password" required>
                </div>
                <button type="submit" name="login" class="btn btn-primary">Kirish</button>
                <a href="index.php" class="btn btn-secondary" style="margin-top: 10px; display: inline-block;">Orqaga</a>
            </form>
        </div>
    </div>
</body>
</html>
<?php
    exit;
}

// Admin panel page
$db = readDB();
?>
<!DOCTYPE html>
<html lang="uz">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Panel</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <div class="container">
        <div class="header">
            <h1>⚙️ Administrator Paneli</h1>
            <a href="?logout=1" class="btn btn-danger" style="position: absolute; right: 20px; top: 20px;">Chiqish</a>
        </div>

        <div class="admin-tabs">
            <button class="tab-btn active" onclick="showTab('lavozimlar')">📋 Lavozimlar</button>
            <button class="tab-btn" onclick="showTab('savollar')">❓ Savollar</button>
            <button class="tab-btn" onclick="showTab('akt_savollar')">📚 Umumiy Savollar</button>
            <button class="tab-btn" onclick="showTab('natijalar')">📊 Natijalar</button>
        </div>

        <!-- Lavozimlar Tab -->
        <div id="lavozimlar" class="tab-content active">
            <h2>Lavozimlar ro'yxati</h2>
            <button onclick="showAddPosition()" class="btn btn-success">➕ Yangi lavozim qo'shish</button>
            
            <div id="addPositionForm" style="display:none;" class="form-box">
                <h3>Yangi lavozim</h3>
                <form id="positionForm" class="test-form">
                    <div class="form-group">
                        <label>Lavozim nomi:</label>
                        <input type="text" id="positionName" required>
                    </div>
                    <button type="submit" class="btn btn-primary">Saqlash</button>
                    <button type="button" onclick="hideAddPosition()" class="btn btn-secondary">Bekor qilish</button>
                </form>
            </div>

            <table class="data-table">
                <thead>
                    <tr>
                        <th>№</th>
                        <th>Lavozim nomi</th>
                        <th>Savollar soni</th>
                        <th>Amallar</th>
                    </tr>
                </thead>
                <tbody id="positionsTable"></tbody>
            </table>
        </div>

        <!-- Savollar Tab -->
        <div id="savollar" class="tab-content">
            <h2>Test savollari</h2>
            <button onclick="showAddQuestion()" class="btn btn-success">➕ Yangi savol qo'shish</button>
            
            <div id="addQuestionForm" style="display:none;" class="form-box">
                <h3>Yangi savol</h3>
                <form id="questionForm" class="test-form">
                    <div class="form-group">
                        <label>Lavozim:</label>
                        <select id="questionPosition" required>
                            <option value="">-- Tanlang --</option>
                        </select>
                    </div>
                    <div class="form-group">
                        <label>Savol matni:</label>
                        <textarea id="questionText" rows="3" required></textarea>
                    </div>
                    <div class="form-group">
                        <label>A) variant:</label>
                        <input type="text" id="optionA" required>
                        <label><input type="radio" name="correct" value="a" required> To'g'ri javob</label>
                    </div>
                    <div class="form-group">
                        <label>B) variant:</label>
                        <input type="text" id="optionB" required>
                        <label><input type="radio" name="correct" value="b"> To'g'ri javob</label>
                    </div>
                    <div class="form-group">
                        <label>C) variant:</label>
                        <input type="text" id="optionC" required>
                        <label><input type="radio" name="correct" value="c"> To'g'ri javob</label>
                    </div>
                    <div class="form-group">
                        <label>D) variant:</label>
                        <input type="text" id="optionD" required>
                        <label><input type="radio" name="correct" value="d"> To'g'ri javob</label>
                    </div>
                    <button type="submit" class="btn btn-primary">Saqlash</button>
                    <button type="button" onclick="hideAddQuestion()" class="btn btn-secondary">Bekor qilish</button>
                </form>
            </div>

            <div class="filter-box">
                <label>Lavozim bo'yicha filtr:</label>
                <select id="filterPosition" onchange="filterQuestions()">
                    <option value="">Barchasi</option>
                </select>
            </div>

            <table class="data-table">
                <thead>
                    <tr>
                        <th>№</th>
                        <th>Lavozim</th>
                        <th>Savol</th>
                        <th>To'g'ri javob</th>
                        <th>Amallar</th>
                    </tr>
                </thead>
                <tbody id="questionsTable"></tbody>
            </table>
        </div>

        <!-- Umumiy Savollar Tab -->
        <div id="akt_savollar" class="tab-content">
            <h2>Umumiy Savollar (Barcha lavozimlar uchun)</h2>
            <button onclick="showAddAktQuestion()" class="btn btn-success">➕ Yangi umumiy savol qo'shish</button>
            
            <div id="addAktQuestionForm" style="display:none;" class="form-box">
                <h3>Yangi umumiy savol</h3>
                <form id="aktQuestionForm" class="test-form">
                    <div class="form-group">
                        <label>Savol matni:</label>
                        <textarea id="aktQuestionText" rows="3" required></textarea>
                    </div>
                    <div class="form-group">
                        <label>A) variant:</label>
                        <input type="text" id="aktOptionA" required>
                        <label><input type="radio" name="aktCorrect" value="a" required> To'g'ri javob</label>
                    </div>
                    <div class="form-group">
                        <label>B) variant:</label>
                        <input type="text" id="aktOptionB" required>
                        <label><input type="radio" name="aktCorrect" value="b"> To'g'ri javob</label>
                    </div>
                    <div class="form-group">
                        <label>C) variant:</label>
                        <input type="text" id="aktOptionC" required>
                        <label><input type="radio" name="aktCorrect" value="c"> To'g'ri javob</label>
                    </div>
                    <div class="form-group">
                        <label>D) variant:</label>
                        <input type="text" id="aktOptionD" required>
                        <label><input type="radio" name="aktCorrect" value="d"> To'g'ri javob</label>
                    </div>
                    <button type="submit" class="btn btn-primary">Saqlash</button>
                    <button type="button" onclick="hideAddAktQuestion()" class="btn btn-secondary">Bekor qilish</button>
                </form>
            </div>

            <table class="data-table">
                <thead>
                    <tr>
                        <th>№</th>
                        <th>Savol</th>
                        <th>To'g'ri javob</th>
                        <th>Amallar</th>
                    </tr>
                </thead>
                <tbody id="aktQuestionsTable"></tbody>
            </table>
        </div>

        <!-- Natijalar Tab -->
        <div id="natijalar" class="tab-content">
            <h2>Test natijalari</h2>
            
            <div class="filter-box">
                <label>Lavozim bo'yicha filtr:</label>
                <select id="filterResultPosition" onchange="filterResults()">
                    <option value="">Barchasi</option>
                </select>
                <button onclick="exportResults()" class="btn btn-primary">📥 Eksport (CSV)</button>
            </div>

            <table class="data-table">
                <thead>
                    <tr>
                        <th>№</th>
                        <th>F.I.O</th>
                        <th>Lavozim</th>
                        <th>Ball</th>
                        <th>Foiz</th>
                        <th>Vaqt</th>
                        <th>Sana</th>
                        <th>Amallar</th>
                    </tr>
                </thead>
                <tbody id="resultsTable"></tbody>
            </table>
        </div>
    </div>

    <script src="admin.js"></script>
    <script>
        // Admin panelni ishga tushirish
        initAdmin();
    </script>
</body>
</html>
<?php
require_once 'config.php';

header('Content-Type: application/json; charset=utf-8');

$action = $_GET['action'] ?? '';
$db = readDB();

// GET lavozimlar
if ($action === 'get_positions') {
    echo json_encode($db['lavozimlar'], JSON_UNESCAPED_UNICODE);
    exit;
}

// GET savollar lavozim bo'yicha
if ($action === 'get_questions' && isset($_GET['position_id'])) {
    $positionId = (int)$_GET['position_id'];
    $questions = array_filter($db['savollar'], function($q) use ($positionId) {
        return $q['lavozim_id'] == $positionId;
    });
    
    // Savollarni random tartibda chiqarish
    $questions = array_values($questions);
    shuffle($questions);
    
    // Har bir savolning variantlarini ham aralashtirish
    foreach ($questions as &$question) {
        $options = [
            ['key' => 'a', 'text' => $question['variant_a']],
            ['key' => 'b', 'text' => $question['variant_b']],
            ['key' => 'c', 'text' => $question['variant_c']],
            ['key' => 'd', 'text' => $question['variant_d']]
        ];
        shuffle($options);
        $question['options'] = $options;
    }
    
    echo json_encode(array_values($questions), JSON_UNESCAPED_UNICODE);
    exit;
}

// POST - Lavozim qo'shish (Admin only)
if ($action === 'add_position' && isAdmin()) {
    $data = json_decode(file_get_contents('php://input'), true);
    
    $newId = count($db['lavozimlar']) > 0 ? max(array_column($db['lavozimlar'], 'id')) + 1 : 1;
    $newPosition = [
        'id' => $newId,
        'nomi' => $data['nomi'],
        'savollar_soni' => 0
    ];
    
    $db['lavozimlar'][] = $newPosition;
    writeDB($db);
    
    echo json_encode(['success' => true, 'data' => $newPosition], JSON_UNESCAPED_UNICODE);
    exit;
}

// POST - Lavozim o'chirish (Admin only)
if ($action === 'delete_position' && isAdmin()) {
    $data = json_decode(file_get_contents('php://input'), true);
    $id = (int)$data['id'];
    
    // Lavozimni o'chirish
    $db['lavozimlar'] = array_values(array_filter($db['lavozimlar'], function($l) use ($id) {
        return $l['id'] != $id;
    }));
    
    // Shu lavozimga tegishli savollarni ham o'chirish
    $db['savollar'] = array_values(array_filter($db['savollar'], function($s) use ($id) {
        return $s['lavozim_id'] != $id;
    }));
    
    writeDB($db);
    
    echo json_encode(['success' => true], JSON_UNESCAPED_UNICODE);
    exit;
}

// POST - Savol qo'shish (Admin only)
if ($action === 'add_question' && isAdmin()) {
    $data = json_decode(file_get_contents('php://input'), true);
    
    $newId = count($db['savollar']) > 0 ? max(array_column($db['savollar'], 'id')) + 1 : 1;
    $newQuestion = [
        'id' => $newId,
        'lavozim_id' => (int)$data['lavozim_id'],
        'savol' => $data['savol'],
        'variant_a' => $data['variant_a'],
        'variant_b' => $data['variant_b'],
        'variant_c' => $data['variant_c'],
        'variant_d' => $data['variant_d'],
        'togri_javob' => $data['togri_javob']
    ];
    
    $db['savollar'][] = $newQuestion;
    
    // Lavozim savollar sonini yangilash
    foreach ($db['lavozimlar'] as &$lav) {
        if ($lav['id'] == $data['lavozim_id']) {
            $lav['savollar_soni']++;
        }
    }
    
    writeDB($db);
    
    echo json_encode(['success' => true, 'data' => $newQuestion], JSON_UNESCAPED_UNICODE);
    exit;
}

// GET - Barcha savollar
if ($action === 'get_all_questions') {
    // Har bir savolning variantlarini ham aralashtirish uchun
    $questions = $db['savollar'];
    
    // Har bir savol uchun options array yaratish
    foreach ($questions as &$question) {
        $options = [
            ['key' => 'a', 'text' => $question['variant_a']],
            ['key' => 'b', 'text' => $question['variant_b']],
            ['key' => 'c', 'text' => $question['variant_c']],
            ['key' => 'd', 'text' => $question['variant_d']]
        ];
        shuffle($options);
        $question['options'] = $options;
    }
    
    echo json_encode($questions, JSON_UNESCAPED_UNICODE);
    exit;
}

// GET - Umumiy savollar (AKT)
if ($action === 'get_akt_questions') {
    $aktDB = readAktDB();
    $questions = $aktDB['umumiy_savollar'];
    
    // Har bir savol uchun options array yaratish
    foreach ($questions as &$question) {
        $options = [
            ['key' => 'a', 'text' => $question['variant_a']],
            ['key' => 'b', 'text' => $question['variant_b']],
            ['key' => 'c', 'text' => $question['variant_c']],
            ['key' => 'd', 'text' => $question['variant_d']]
        ];
        shuffle($options);
        $question['options'] = $options;
    }
    
    echo json_encode($questions, JSON_UNESCAPED_UNICODE);
    exit;
}

// GET - Admin uchun umumiy savollar (shuffle qilinmagan)
if ($action === 'get_admin_akt_questions' && isAdmin()) {
    $aktDB = readAktDB();
    echo json_encode($aktDB['umumiy_savollar'], JSON_UNESCAPED_UNICODE);
    exit;
}

// POST - Umumiy savol qo'shish (Admin only)
if ($action === 'add_akt_question' && isAdmin()) {
    $data = json_decode(file_get_contents('php://input'), true);
    $aktDB = readAktDB();
    
    $newId = count($aktDB['umumiy_savollar']) > 0 ? max(array_column($aktDB['umumiy_savollar'], 'id')) + 1 : 1;
    $newQuestion = [
        'id' => $newId,
        'savol' => $data['savol'],
        'variant_a' => $data['variant_a'],
        'variant_b' => $data['variant_b'],
        'variant_c' => $data['variant_c'],
        'variant_d' => $data['variant_d'],
        'togri_javob' => $data['togri_javob']
    ];
    
    $aktDB['umumiy_savollar'][] = $newQuestion;
    writeAktDB($aktDB);
    
    echo json_encode(['success' => true, 'data' => $newQuestion], JSON_UNESCAPED_UNICODE);
    exit;
}

// POST - Umumiy savolni o'chirish (Admin only)
if ($action === 'delete_akt_question' && isAdmin()) {
    $data = json_decode(file_get_contents('php://input'), true);
    $id = (int)$data['id'];
    $aktDB = readAktDB();
    
    $aktDB['umumiy_savollar'] = array_values(array_filter($aktDB['umumiy_savollar'], function($s) use ($id) {
        return $s['id'] != $id;
    }));
    
    writeAktDB($aktDB);
    
    echo json_encode(['success' => true], JSON_UNESCAPED_UNICODE);
    exit;
}

// POST - Umumiy savolni tahrirlash (Admin only)
if ($action === 'edit_akt_question' && isAdmin()) {
    $data = json_decode(file_get_contents('php://input'), true);
    $id = (int)$data['id'];
    $aktDB = readAktDB();
    
    foreach ($aktDB['umumiy_savollar'] as &$savol) {
        if ($savol['id'] == $id) {
            $savol['savol'] = $data['savol'];
            $savol['variant_a'] = $data['variant_a'];
            $savol['variant_b'] = $data['variant_b'];
            $savol['variant_c'] = $data['variant_c'];
            $savol['variant_d'] = $data['variant_d'];
            $savol['togri_javob'] = $data['togri_javob'];
            break;
        }
    }
    
    writeAktDB($aktDB);
    echo json_encode(['success' => true], JSON_UNESCAPED_UNICODE);
    exit;
}

// GET - Admin uchun barcha savollar (shuffle qilinmagan)
if ($action === 'get_admin_questions' && isAdmin()) {
    echo json_encode($db['savollar'], JSON_UNESCAPED_UNICODE);
    exit;
}

// POST - Savol o'chirish (Admin only)
if ($action === 'delete_question' && isAdmin()) {
    $data = json_decode(file_get_contents('php://input'), true);
    $id = (int)$data['id'];
    
    // Savolni topish va lavozim_id ni olish
    $question = array_filter($db['savollar'], function($s) use ($id) {
        return $s['id'] == $id;
    });
    
    if ($question) {
        $question = array_values($question)[0];
        $lavozimId = $question['lavozim_id'];
        
        // Savolni o'chirish
        $db['savollar'] = array_values(array_filter($db['savollar'], function($s) use ($id) {
            return $s['id'] != $id;
        }));
        
        // Lavozim savollar sonini yangilash
        foreach ($db['lavozimlar'] as &$lav) {
            if ($lav['id'] == $lavozimId) {
                $lav['savollar_soni'] = max(0, $lav['savollar_soni'] - 1);
            }
        }
        
        writeDB($db);
    }
    
    echo json_encode(['success' => true], JSON_UNESCAPED_UNICODE);
    exit;
}

// POST - Natijani saqlash
if ($action === 'save_result') {
    $data = json_decode(file_get_contents('php://input'), true);
    
    $newId = count($db['natijalar']) > 0 ? max(array_column($db['natijalar'], 'id')) + 1 : 1;
    $newResult = [
        'id' => $newId,
        'fio' => $data['fio'],
        'lavozim_id' => (int)$data['lavozim_id'],
        'lavozim_nomi' => $data['lavozim_nomi'],
        'jami_savollar' => (int)$data['jami_savollar'],
        'togri_javoblar' => (int)$data['togri_javoblar'],
        'foiz' => (float)$data['foiz'],
        'vaqt' => $data['vaqt'],
        'sana' => date('Y-m-d H:i:s')
    ];
    
    $db['natijalar'][] = $newResult;
    writeDB($db);
    
    echo json_encode(['success' => true, 'data' => $newResult], JSON_UNESCAPED_UNICODE);
    exit;
}

// GET - Natijalar (Admin only)
if ($action === 'get_results' && isAdmin()) {
    // Natijalarni sanasi bo'yicha tartiblash (eng yangi birinchi)
    usort($db['natijalar'], function($a, $b) {
        return strtotime($b['sana']) - strtotime($a['sana']);
    });
    
    echo json_encode($db['natijalar'], JSON_UNESCAPED_UNICODE);
    exit;
}

// POST - Natijani o'chirish (Admin only)
if ($action === 'delete_result' && isAdmin()) {
    $data = json_decode(file_get_contents('php://input'), true);
    $id = (int)$data['id'];
    
    $db['natijalar'] = array_values(array_filter($db['natijalar'], function($r) use ($id) {
        return $r['id'] != $id;
    }));
    
    writeDB($db);
    
    echo json_encode(['success' => true], JSON_UNESCAPED_UNICODE);
    exit;
}

// POST - Natijani ulashish uchun hash yaratish
if ($action === 'share_result') {
    $data = json_decode(file_get_contents('php://input'), true);
    
    // Unique hash yaratish
    $hash = bin2hex(random_bytes(16));
    
    $shareData = [
        'hash' => $hash,
        'natija_id' => (int)$data['natija_id'],
        'fio' => $data['fio'],
        'lavozim_nomi' => $data['lavozim_nomi'],
        'jami_savollar' => (int)$data['jami_savollar'],
        'togri_javoblar' => (int)$data['togri_javoblar'],
        'foiz' => (float)$data['foiz'],
        'vaqt' => $data['vaqt'],
        'sana' => $data['sana'],
        'yaratilgan' => date('Y-m-d H:i:s')
    ];
    
    $db['ulashilgan_natijalar'][] = $shareData;
    writeDB($db);
    
    echo json_encode(['success' => true, 'hash' => $hash], JSON_UNESCAPED_UNICODE);
    exit;
}

// GET - Ulashilgan natijani ko'rish
if ($action === 'get_shared_result' && isset($_GET['hash'])) {
    $hash = $_GET['hash'];
    
    $shared = array_filter($db['ulashilgan_natijalar'], function($s) use ($hash) {
        return $s['hash'] === $hash;
    });
    
    if ($shared) {
        echo json_encode(['success' => true, 'data' => array_values($shared)[0]], JSON_UNESCAPED_UNICODE);
    } else {
        echo json_encode(['success' => false, 'message' => 'Natija topilmadi'], JSON_UNESCAPED_UNICODE);
    }
    exit;
}

// POST - Lavozimni tahrirlash (Admin only)
if ($action === 'edit_position' && isAdmin()) {
    $data = json_decode(file_get_contents('php://input'), true);
    $id = (int)$data['id'];
    
    foreach ($db['lavozimlar'] as &$lav) {
        if ($lav['id'] == $id) {
            $lav['nomi'] = $data['nomi'];
            break;
        }
    }
    
    writeDB($db);
    echo json_encode(['success' => true], JSON_UNESCAPED_UNICODE);
    exit;
}

// POST - Savolni tahrirlash (Admin only)
if ($action === 'edit_question' && isAdmin()) {
    $data = json_decode(file_get_contents('php://input'), true);
    $id = (int)$data['id'];
    
    foreach ($db['savollar'] as &$savol) {
        if ($savol['id'] == $id) {
            $savol['lavozim_id'] = (int)$data['lavozim_id'];
            $savol['savol'] = $data['savol'];
            $savol['variant_a'] = $data['variant_a'];
            $savol['variant_b'] = $data['variant_b'];
            $savol['variant_c'] = $data['variant_c'];
            $savol['variant_d'] = $data['variant_d'];
            $savol['togri_javob'] = $data['togri_javob'];
            break;
        }
    }
    
    writeDB($db);
    echo json_encode(['success' => true], JSON_UNESCAPED_UNICODE);
    exit;
}

// GET - Top 5 natijalar
if ($action === 'get_top_results') {
    // Natijalarni foiz bo'yicha tartiblash
    usort($db['natijalar'], function($a, $b) {
        if ($b['foiz'] == $a['foiz']) {
            // Agar foiz bir xil bo'lsa, vaqt bo'yicha
            return strcmp($a['vaqt'], $b['vaqt']);
        }
        return $b['foiz'] - $a['foiz'];
    });
    
    // Faqat 5 tasini olish
    $top5 = array_slice($db['natijalar'], 0, 5);
    
    echo json_encode($top5, JSON_UNESCAPED_UNICODE);
    exit;
}

// Noto'g'ri so'rov
echo json_encode(['error' => 'Invalid action'], JSON_UNESCAPED_UNICODE);
// admin.js - Admin panel funksiyalari

let adminData = {
    positions: [],
    questions: [],
    results: []
};

// initAdmin ga umumiy savollarni yuklashni qo'shish
const originalInitAdmin = initAdmin;
initAdmin = async function() {
    await originalInitAdmin();
    await loadAktQuestions();
};

// Barcha ma'lumotlarni yuklash
async function loadAllData() {
    try {
        // Lavozimlar
        const posRes = await fetch('api.php?action=get_positions');
        adminData.positions = await posRes.json();
        
        // Savollar
        const quesRes = await fetch('api.php?action=get_admin_questions');
        adminData.questions = await quesRes.json();
        
        // Natijalar
        const resRes = await fetch('api.php?action=get_results');
        adminData.results = await resRes.json();
        
        // Ma'lumotlarni ko'rsatish
        renderPositions();
        renderQuestions();
        renderResults();
        updateFilters();
        
    } catch (error) {
        console.error('Ma\'lumotlarni yuklashda xatolik:', error);
        alert('Ma\'lumotlarni yuklashda xatolik yuz berdi!');
    }
}

// Tab almashtirish
function showTab(tabName, event = null) {
    document.querySelectorAll('.tab-content').forEach(tab => {
        tab.classList.remove('active');
    });
    
    document.querySelectorAll('.tab-btn').forEach(btn => {
        btn.classList.remove('active');
    });

    document.getElementById(tabName).classList.add('active');
    
    // faqat event mavjud bo‘lsa ishlasin
    if (event && event.target) {
        event.target.classList.add('active');
    }
}


// Lavozimlar
function renderPositions() {
    const tbody = document.getElementById('positionsTable');
    tbody.innerHTML = '';
    
    adminData.positions.forEach((pos, index) => {
        const tr = document.createElement('tr');
        tr.innerHTML = `
            <td>${index + 1}</td>
            <td>${pos.nomi}</td>
            <td>${pos.savollar_soni}</td>
            <td>
                <button onclick="editPosition(${pos.id})" class="btn btn-primary btn-sm">✏️ Tahrirlash</button>
                <button onclick="deletePosition(${pos.id})" class="btn btn-danger btn-sm">🗑️ O'chirish</button>
            </td>
        `;
        tbody.appendChild(tr);
    });
}

function showAddPosition() {
    document.getElementById('addPositionForm').style.display = 'block';
    document.getElementById('positionName').value = '';
}

function hideAddPosition() {
    document.getElementById('addPositionForm').style.display = 'none';
}

document.getElementById('positionForm')?.addEventListener('submit', async (e) => {
    e.preventDefault();
    
    const name = document.getElementById('positionName').value.trim();
    if (!name) { alert('Lavozim nomini kiriting!'); return; }
    
    try {
        const response = await fetch('api.php?action=add_position', {
            method: 'POST',
            headers: {'Content-Type': 'application/json'},
            body: JSON.stringify({ nomi: name })
        });
        
        const result = await response.json();
        if (result.success) {
            alert('Lavozim qo\'shildi!');
            hideAddPosition();
            await loadAllData();
        }
    } catch (error) {
        alert('Xatolik!');
    }
});

async function deletePosition(id) {
    if (!confirm('O\'chirmoqchimisiz?')) return;
    
    try {
        await fetch('api.php?action=delete_position', {
            method: 'POST',
            headers: {'Content-Type': 'application/json'},
            body: JSON.stringify({ id })
        });
        alert('O\'chirildi!');
        await loadAllData();
    } catch (error) {
        alert('Xatolik!');
    }
}

// Savollar
function renderQuestions(filterId = null) {
    const tbody = document.getElementById('questionsTable');
    tbody.innerHTML = '';
    
    let filtered = filterId ? adminData.questions.filter(q => q.lavozim_id == filterId) : adminData.questions;
    
    if (filtered.length === 0) {
        tbody.innerHTML = '<tr><td colspan="5" style="text-align:center;">Savollar topilmadi</td></tr>';
        return;
    }
    
    filtered.forEach((ques, index) => {
        const pos = adminData.positions.find(p => p.id === ques.lavozim_id);
        const tr = document.createElement('tr');
        tr.innerHTML = `
            <td>${index + 1}</td>
            <td>${pos ? pos.nomi : 'N/A'}</td>
            <td>${ques.savol.substring(0, 50)}...</td>
            <td>${ques.togri_javob.toUpperCase()}) ${ques['variant_' + ques.togri_javob].substring(0, 30)}...</td>
            <td>
                <button onclick="viewQuestion(${ques.id})" class="btn btn-primary btn-sm">👁️</button>
                <button onclick="editQuestion(${ques.id})" class="btn btn-secondary btn-sm">✏️</button>
                <button onclick="deleteQuestion(${ques.id})" class="btn btn-danger btn-sm">🗑️</button>
            </td>
        `;
        tbody.appendChild(tr);
    });
}

function showAddQuestion() {
    document.getElementById('addQuestionForm').style.display = 'block';
    const select = document.getElementById('questionPosition');
    select.innerHTML = '<option value="">-- Tanlang --</option>';
    adminData.positions.forEach(pos => {
        select.innerHTML += `<option value="${pos.id}">${pos.nomi}</option>`;
    });
    document.getElementById('questionForm').reset();
}

function hideAddQuestion() {
    document.getElementById('addQuestionForm').style.display = 'none';
}

document.getElementById('questionForm')?.addEventListener('submit', async (e) => {
    e.preventDefault();
    
    const data = {
        lavozim_id: document.getElementById('questionPosition').value,
        savol: document.getElementById('questionText').value.trim(),
        variant_a: document.getElementById('optionA').value.trim(),
        variant_b: document.getElementById('optionB').value.trim(),
        variant_c: document.getElementById('optionC').value.trim(),
        variant_d: document.getElementById('optionD').value.trim(),
        togri_javob: document.querySelector('input[name="correct"]:checked')?.value
    };
    
    if (!data.lavozim_id || !data.savol || !data.togri_javob) {
        alert('Barcha maydonlarni to\'ldiring!');
        return;
    }
    
    try {
        await fetch('api.php?action=add_question', {
            method: 'POST',
            headers: {'Content-Type': 'application/json'},
            body: JSON.stringify(data)
        });
        alert('Savol qo\'shildi!');
        hideAddQuestion();
        await loadAllData();
    } catch (error) {
        alert('Xatolik!');
    }
});

function viewQuestion(id) {
    const q = adminData.questions.find(x => x.id === id);
    if (!q) return;
    const p = adminData.positions.find(x => x.id === q.lavozim_id);
    alert(`Lavozim: ${p.nomi}\n\n${q.savol}\n\nA) ${q.variant_a}\nB) ${q.variant_b}\nC) ${q.variant_c}\nD) ${q.variant_d}\n\n✅ ${q.togri_javob.toUpperCase()}`);
}

async function deleteQuestion(id) {
    if (!confirm('O\'chirmoqchimisiz?')) return;
    try {
        await fetch('api.php?action=delete_question', {
            method: 'POST',
            headers: {'Content-Type': 'application/json'},
            body: JSON.stringify({ id })
        });
        alert('O\'chirildi!');
        await loadAllData();
    } catch (error) {
        alert('Xatolik!');
    }
}

function filterQuestions() {
    const filterId = document.getElementById('filterPosition').value;
    renderQuestions(filterId || null);
}

// Natijalar
function renderResults(filterId = null) {
    const tbody = document.getElementById('resultsTable');
    tbody.innerHTML = '';
    
    let filtered = filterId ? adminData.results.filter(r => r.lavozim_id == filterId) : adminData.results;
    
    if (filtered.length === 0) {
        tbody.innerHTML = '<tr><td colspan="8" style="text-align:center;">Natijalar topilmadi</td></tr>';
        return;
    }
    
    filtered.forEach((res, index) => {
        const date = new Date(res.sana);
        let color = res.foiz >= 90 ? '#28a745' : res.foiz >= 80 ? '#17a2b8' : res.foiz >= 70 ? '#ffc107' : '#dc3545';
        
        const tr = document.createElement('tr');
        tr.innerHTML = `
            <td>${index + 1}</td>
            <td>${res.fio}</td>
            <td>${res.lavozim_nomi}</td>
            <td>${res.togri_javoblar}/${res.jami_savollar}</td>
            <td style="color: ${color}; font-weight: bold;">${res.foiz}%</td>
            <td>${res.vaqt}</td>
            <td>${date.toLocaleDateString('uz-UZ')} ${date.toLocaleTimeString('uz-UZ')}</td>
            <td>
                <button onclick="deleteResult(${res.id})" class="btn btn-danger btn-sm">🗑️</button>
            </td>
        `;
        tbody.appendChild(tr);
    });
}

function filterResults() {
    renderResults(document.getElementById('filterResultPosition').value || null);
}

async function deleteResult(id) {
    if (!confirm('O\'chirmoqchimisiz?')) return;
    try {
        await fetch('api.php?action=delete_result', {
            method: 'POST',
            headers: {'Content-Type': 'application/json'},
            body: JSON.stringify({ id })
        });
        alert('O\'chirildi!');
        await loadAllData();
    } catch (error) {
        alert('Xatolik!');
    }
}

function exportResults() {
    if (adminData.results.length === 0) { alert('Natijalar yo\'q!'); return; }
    
    let csv = 'F.I.O,Lavozim,Jami,To\'g\'ri,Foiz,Vaqt,Sana\n';
    adminData.results.forEach(r => {
        csv += `"${r.fio}","${r.lavozim_nomi}",${r.jami_savollar},${r.togri_javoblar},${r.foiz},"${r.vaqt}","${r.sana}"\n`;
    });
    
    const blob = new Blob([csv], { type: 'text/csv;charset=utf-8;' });
    const link = document.createElement('a');
    link.href = URL.createObjectURL(blob);
    link.download = `natijalar_${new Date().toISOString().split('T')[0]}.csv`;
    link.click();
}

function updateFilters() {
    ['filterPosition', 'filterResultPosition'].forEach(id => {
        const el = document.getElementById(id);
        if (el) {
            el.innerHTML = '<option value="">Barchasi</option>';
            adminData.positions.forEach(p => {
                el.innerHTML += `<option value="${p.id}">${p.nomi}</option>`;
            });
        }
    });
}

// Lavozimni tahrirlash
let editingPositionId = null;

function editPosition(id) {
    const position = adminData.positions.find(p => p.id === id);
    if (!position) return;
    
    editingPositionId = id;
    document.getElementById('positionName').value = position.nomi;
    document.getElementById('addPositionForm').style.display = 'block';
    
    // Formani tahrirlash rejimiga o'tkazish
    const form = document.getElementById('positionForm');
    const submitBtn = form.querySelector('button[type="submit"]');
    submitBtn.textContent = 'Yangilash';
}

// Lavozim formasi submit hodisasini yangilash
document.getElementById('positionForm')?.addEventListener('submit', async (e) => {
    e.preventDefault();
    
    const name = document.getElementById('positionName').value.trim();
    if (!name) { alert('Lavozim nomini kiriting!'); return; }
    
    try {
        let action = editingPositionId ? 'edit_position' : 'add_position';
        let data = { nomi: name };
        
        if (editingPositionId) {
            data.id = editingPositionId;
        }
        
        const response = await fetch(`api.php?action=${action}`, {
            method: 'POST',
            headers: {'Content-Type': 'application/json'},
            body: JSON.stringify(data)
        });
        
        const result = await response.json();
        if (result.success) {
            alert(editingPositionId ? 'Lavozim yangilandi!' : 'Lavozim qo\'shildi!');
            hideAddPosition();
            editingPositionId = null;
            await loadAllData();
        }
    } catch (error) {
        alert('Xatolik!');
    }
});

// hideAddPosition funksiyasini yangilash
function hideAddPosition() {
    document.getElementById('addPositionForm').style.display = 'none';
    editingPositionId = null;
    const form = document.getElementById('positionForm');
    const submitBtn = form.querySelector('button[type="submit"]');
    submitBtn.textContent = 'Saqlash';
}

// Savolni tahrirlash
let editingQuestionId = null;

function editQuestion(id) {
    const question = adminData.questions.find(q => q.id === id);
    if (!question) return;
    
    editingQuestionId = id;
    
    // Formani ko'rsatish
    document.getElementById('addQuestionForm').style.display = 'block';
    
    // Lavozimlar selectni to'ldirish
    const select = document.getElementById('questionPosition');
    select.innerHTML = '<option value="">-- Tanlang --</option>';
    adminData.positions.forEach(pos => {
        select.innerHTML += `<option value="${pos.id}" ${pos.id === question.lavozim_id ? 'selected' : ''}>${pos.nomi}</option>`;
    });
    
    // Form maydonlarini to'ldirish
    document.getElementById('questionText').value = question.savol;
    document.getElementById('optionA').value = question.variant_a;
    document.getElementById('optionB').value = question.variant_b;
    document.getElementById('optionC').value = question.variant_c;
    document.getElementById('optionD').value = question.variant_d;
    
    // To'g'ri javobni belgilash
    document.querySelector(`input[name="correct"][value="${question.togri_javob}"]`).checked = true;
    
    // Submit tugmasini o'zgartirish
    const form = document.getElementById('questionForm');
    const submitBtn = form.querySelector('button[type="submit"]');
    submitBtn.textContent = 'Yangilash';
}

// Savol formasi submit hodisasini yangilash
document.getElementById('questionForm')?.addEventListener('submit', async (e) => {
    e.preventDefault();
    
    const data = {
        lavozim_id: document.getElementById('questionPosition').value,
        savol: document.getElementById('questionText').value.trim(),
        variant_a: document.getElementById('optionA').value.trim(),
        variant_b: document.getElementById('optionB').value.trim(),
        variant_c: document.getElementById('optionC').value.trim(),
        variant_d: document.getElementById('optionD').value.trim(),
        togri_javob: document.querySelector('input[name="correct"]:checked')?.value
    };
    
    if (!data.lavozim_id || !data.savol || !data.togri_javob) {
        alert('Barcha maydonlarni to\'ldiring!');
        return;
    }
    
    try {
        let action = editingQuestionId ? 'edit_question' : 'add_question';
        if (editingQuestionId) {
            data.id = editingQuestionId;
        }
        
        await fetch(`api.php?action=${action}`, {
            method: 'POST',
            headers: {'Content-Type': 'application/json'},
            body: JSON.stringify(data)
        });
        
        alert(editingQuestionId ? 'Savol yangilandi!' : 'Savol qo\'shildi!');
        hideAddQuestion();
        editingQuestionId = null;
        await loadAllData();
    } catch (error) {
        alert('Xatolik!');
    }
});

// hideAddQuestion funksiyasini yangilash
function hideAddQuestion() {
    document.getElementById('addQuestionForm').style.display = 'none';
    editingQuestionId = null;
    const form = document.getElementById('questionForm');
    const submitBtn = form.querySelector('button[type="submit"]');
    submitBtn.textContent = 'Saqlash';
    document.getElementById('questionForm').reset();
}


// ===== UMUMIY SAVOLLAR (AKT) FUNKSIYALARI =====

let aktQuestions = [];
let editingAktQuestionId = null;

// Umumiy savollarni yuklash
async function loadAktQuestions() {
    try {
        const response = await fetch('api.php?action=get_admin_akt_questions');
        aktQuestions = await response.json();
        renderAktQuestions();
    } catch (error) {
        console.error('Xatolik:', error);
    }
}

// Umumiy savollarni ko'rsatish
function renderAktQuestions() {
    const tbody = document.getElementById('aktQuestionsTable');
    if (!tbody) return;
    
    tbody.innerHTML = '';
    
    aktQuestions.forEach((ques, index) => {
        const tr = document.createElement('tr');
        tr.innerHTML = `
            <td>${index + 1}</td>
            <td>${ques.savol.substring(0, 80)}...</td>
            <td>${ques.togri_javob.toUpperCase()}) ${ques['variant_' + ques.togri_javob].substring(0, 30)}...</td>
            <td>
                <button onclick="viewAktQuestion(${ques.id})" class="btn btn-primary btn-sm">👁️</button>
                <button onclick="editAktQuestion(${ques.id})" class="btn btn-secondary btn-sm">✏️</button>
                <button onclick="deleteAktQuestion(${ques.id})" class="btn btn-danger btn-sm">🗑️</button>
            </td>
        `;
        tbody.appendChild(tr);
    });
}

// Umumiy savol qo'shish formasini ko'rsatish
function showAddAktQuestion() {
    document.getElementById('addAktQuestionForm').style.display = 'block';
    document.getElementById('aktQuestionForm').reset();
    editingAktQuestionId = null;
}

// Umumiy savol qo'shish formasini yashirish
function hideAddAktQuestion() {
    document.getElementById('addAktQuestionForm').style.display = 'none';
    editingAktQuestionId = null;
    const form = document.getElementById('aktQuestionForm');
    const submitBtn = form.querySelector('button[type="submit"]');
    submitBtn.textContent = 'Saqlash';
    document.getElementById('aktQuestionForm').reset();
}

// Umumiy savol formasi submit
document.getElementById('aktQuestionForm')?.addEventListener('submit', async (e) => {
    e.preventDefault();
    
    const data = {
        savol: document.getElementById('aktQuestionText').value.trim(),
        variant_a: document.getElementById('aktOptionA').value.trim(),
        variant_b: document.getElementById('aktOptionB').value.trim(),
        variant_c: document.getElementById('aktOptionC').value.trim(),
        variant_d: document.getElementById('aktOptionD').value.trim(),
        togri_javob: document.querySelector('input[name="aktCorrect"]:checked')?.value
    };
    
    if (!data.savol || !data.togri_javob) {
        alert('Barcha maydonlarni to\'ldiring!');
        return;
    }
    
    try {
        let action = editingAktQuestionId ? 'edit_akt_question' : 'add_akt_question';
        if (editingAktQuestionId) {
            data.id = editingAktQuestionId;
        }
        
        await fetch(`api.php?action=${action}`, {
            method: 'POST',
            headers: {'Content-Type': 'application/json'},
            body: JSON.stringify(data)
        });
        
        alert(editingAktQuestionId ? 'Savol yangilandi!' : 'Savol qo\'shildi!');
        hideAddAktQuestion();
        editingAktQuestionId = null;
        await loadAktQuestions();
    } catch (error) {
        alert('Xatolik!');
    }
});

// Umumiy savolni ko'rish
function viewAktQuestion(id) {
    const question = aktQuestions.find(q => q.id === id);
    if (!question) return;
    
    const correctLetter = question.togri_javob.toUpperCase();
    
    alert(`
SAVOL:
${question.savol}

A) ${question.variant_a}
B) ${question.variant_b}
C) ${question.variant_c}
D) ${question.variant_d}

TO'G'RI JAVOB: ${correctLetter}) ${question['variant_' + question.togri_javob]}
    `.trim());
}

// Umumiy savolni tahrirlash
function editAktQuestion(id) {
    const question = aktQuestions.find(q => q.id === id);
    if (!question) return;
    
    editingAktQuestionId = id;
    
    document.getElementById('addAktQuestionForm').style.display = 'block';
    document.getElementById('aktQuestionText').value = question.savol;
    document.getElementById('aktOptionA').value = question.variant_a;
    document.getElementById('aktOptionB').value = question.variant_b;
    document.getElementById('aktOptionC').value = question.variant_c;
    document.getElementById('aktOptionD').value = question.variant_d;
    
    document.querySelector(`input[name="aktCorrect"][value="${question.togri_javob}"]`).checked = true;
    
    const form = document.getElementById('aktQuestionForm');
    const submitBtn = form.querySelector('button[type="submit"]');
    submitBtn.textContent = 'Yangilash';
}

// Umumiy savolni o'chirish
async function deleteAktQuestion(id) {
    if (!confirm('Ushbu umumiy savolni o\'chirmoqchimisiz?')) return;
    
    try {
        await fetch('api.php?action=delete_akt_question', {
            method: 'POST',
            headers: {'Content-Type': 'application/json'},
            body: JSON.stringify({id: id})
        });
        
        alert('Savol o\'chirildi!');
        await loadAktQuestions();
    } catch (error) {
        alert('Xatolik!');
    }
}
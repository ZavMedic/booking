<?php require_once 'config.php'; ?>
<!DOCTYPE html>
<html lang="uz">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Test Natijasi - by Dr.Qurbonov</title>
    <link rel="stylesheet" href="style.css">
    <meta property="og:title" content="Test Natijasi - Tibbiy Klinika">
    <meta property="og:description" content="Test natijasini ko'ring">
    <meta property="og:type" content="website">
</head>
<body>
    <div class="container">
        <div class="header">
            <h1>📊 Test Natijasi</h1>
        </div>

        <div class="result-container" id="sharedResultContainer">
            <div class="result-box" id="sharedResultBox">
                <div style="text-align: center; padding: 40px;">
                    <p>Yuklanmoqda...</p>
                </div>
            </div>
        </div>

        <div class="footer">
            <p>&copy; 2025 Tibbiy Klinika. Barcha huquqlar himoyalangan.</p>
            <a href="index.php" class="btn btn-primary" style="margin-top: 10px;">🏠 Bosh sahifa</a>
        </div>
    </div>

    <script>
        // URL dan hash olish
        const urlParams = new URLSearchParams(window.location.search);
        const hash = urlParams.get('hash');

        if (!hash) {
            document.getElementById('sharedResultBox').innerHTML = `
                <div style="text-align: center; padding: 40px;">
                    <h2 style="color: #dc3545;">❌ Xatolik</h2>
                    <p>Noto'g'ri havola!</p>
                    <a href="index.php" class="btn btn-primary" style="margin-top: 20px;">🏠 Bosh sahifa</a>
                </div>
            `;
        } else {
            // Natijani yuklash
            loadSharedResult(hash);
        }

        async function loadSharedResult(hash) {
            try {
                const response = await fetch(`api.php?action=get_shared_result&hash=${hash}`);
                const result = await response.json();

                if (result.success) {
                    const data = result.data;
                    
                    // Baholash
                    let grade = '';
                    let gradeColor = '';
                    
                    if (data.foiz >= 90) {
                        grade = 'A\'LO';
                        gradeColor = '#28a745';
                    } else if (data.foiz >= 80) {
                        grade = 'YAXSHI';
                        gradeColor = '#17a2b8';
                    } else if (data.foiz >= 70) {
                        grade = 'QONIQARLI';
                        gradeColor = '#ffc107';
                    } else {
                        grade = 'QONIQARSIZ';
                        gradeColor = '#dc3545';
                    }

                    const date = new Date(data.sana);
                    
                    document.getElementById('sharedResultBox').innerHTML = `
                        <h2 style="color: ${gradeColor};">🎉 ${grade}!</h2>
                        <div class="result-score" style="background: ${gradeColor};">
                            <div style="font-size: 0.6em; margin-bottom: 10px;">Natija:</div>
                            ${data.foiz}%
                            <div style="font-size: 0.5em; margin-top: 10px;">${data.togri_javoblar} / ${data.jami_savollar} to'g'ri</div>
                        </div>
                        <div class="result-details">
                            <p><strong>👤 F.I.O:</strong> ${data.fio}</p>
                            <p><strong>💼 Lavozim:</strong> ${data.lavozim_nomi}</p>
                            <p><strong>📊 Jami savollar:</strong> ${data.jami_savollar} ta</p>
                            <p><strong>✅ To'g'ri javoblar:</strong> ${data.togri_javoblar} ta</p>
                            <p><strong>❌ Noto'g'ri javoblar:</strong> ${data.jami_savollar - data.togri_javoblar} ta</p>
                            <p><strong>📈 Natija:</strong> ${data.foiz}% (${grade})</p>
                            <p><strong>⏱️ Sarflangan vaqt:</strong> ${data.vaqt}</p>
                            <p><strong>📅 Sana:</strong> ${date.toLocaleString('uz-UZ')}</p>
                        </div>
                        <div style="text-align: center; margin-top: 20px;">
                            <button onclick="window.print()" class="btn btn-secondary">🖨️ Chop etish</button>
                        </div>
                    `;
                } else {
                    document.getElementById('sharedResultBox').innerHTML = `
                        <div style="text-align: center; padding: 40px;">
                            <h2 style="color: #dc3545;">❌ Natija topilmadi</h2>
                            <p>Havola yaroqsiz yoki eskirgan.</p>
                            <a href="index.php" class="btn btn-primary" style="margin-top: 20px;">🏠 Bosh sahifa</a>
                        </div>
                    `;
                }
            } catch (error) {
                console.error('Xatolik:', error);
                document.getElementById('sharedResultBox').innerHTML = `
                    <div style="text-align: center; padding: 40px;">
                        <h2 style="color: #dc3545;">❌ Xatolik</h2>
                        <p>Natijani yuklashda xatolik yuz berdi.</p>
                        <a href="index.php" class="btn btn-primary" style="margin-top: 20px;">🏠 Bosh sahifa</a>
                    </div>
                `;
            }
        }
    </script>
</body>
</html>
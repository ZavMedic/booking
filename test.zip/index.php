<?php require_once 'config.php'; ?>
<!DOCTYPE html>
<html lang="uz">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Test Tizimi - By Dr.Qurbonov</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <div class="container">
        <div class="header">
            <h1>🏥 Test Tizimi</h1>
            <p>Xodimlar uchun bilim darajasini tekshirish</p>
        </div>

        <div class="main-content">
            <div class="welcome-box">
                <h2>Xush kelibsiz!</h2>
                <p>Test topshirish uchun lavozimingizni tanlang va ma'lumotlaringizni kiriting.</p>
            </div>

            <form id="startForm" class="test-form">
                <div class="form-group">
                    <label for="fullname">
                        <i>👤</i> To'liq ismingiz (F.I.O):
                    </label>
                    <input type="text" id="fullname" name="fullname" required placeholder="Masalan: Aliyev Vali Akramovich">
                </div>

                <div class="form-group">
                    <label for="position">
                        <i>💼</i> Lavozimingiz:
                    </label>
                    <select id="position" name="position" required>
                        <option value="">-- Lavozimni tanlang --</option>
                    </select>
                </div>

                <button type="submit" class="btn btn-primary">
                    📝 Testni Boshlash
                </button>
            </form>

            <!-- Top 5 natijalar -->
            <div class="top-results" id="topResults" style="margin-top: 40px;">
                <h3 style="text-align: center; color: #667eea; margin-bottom: 20px;">
                    🏆 Top 5 Eng Yaxshi Natijalar
                </h3>
                <div id="topResultsList"></div>
            </div>

            <div class="admin-link">
                <a href="admin.php">🔐 Administrator</a>
            </div>
        </div>

        <div class="footer">
            <p>&copy; Production by Dr.QURBONOV 2025</p>
        </div>
    </div>

    <script src="script.js"></script>
    <script>
async function loadTopResults() {
    const container = document.getElementById('topResultsList');
    if (!container) return;

    try {
        const response = await fetch('api.php?action=get_top_results');
        const results = await response.json();

        if (!Array.isArray(results) || results.length === 0) {
            container.innerHTML = `
                <p style="text-align:center; color:#999;">
                    Hozircha natijalar yo‘q 😔
                </p>`;
            return;
        }

        let html = '<div class="top-list">';
        results.forEach((r, i) => {
            const medal = i === 0 ? '🥇' : i === 1 ? '🥈' : i === 2 ? '🥉' : '🏅';
            const color =
                r.foiz >= 90 ? '#28a745' :
                r.foiz >= 80 ? '#17a2b8' :
                r.foiz >= 70 ? '#ffc107' : '#dc3545';

            html += `
                <div style="display:flex; justify-content:space-between;
                    align-items:center; background:#f8f9fa;
                    border-left:5px solid ${color}; border-radius:10px;
                    padding:10px 15px; margin-bottom:10px;">
                    <div style="display:flex; align-items:center; gap:12px;">
                        <span style="font-size:1.8em;">${medal}</span>
                        <div>
                            <div style="font-weight:600; color:#222;">${r.fio}</div>
                            <div style="font-size:0.9em; color:#666;">${r.lavozim_nomi}</div>
                            <div style="font-size:0.8em; color:#aaa;">${r.vaqt}</div>
                        </div>
                    </div>
                    <div style="font-weight:bold; font-size:1.5em; color:${color};">${r.foiz}%</div>
                </div>`;
        });
        html += '</div>';
        container.innerHTML = html;

    } catch (e) {
        console.error(e);
        container.innerHTML = `
            <p style="text-align:center; color:red;">⚠️ Xatolik: yuklab bo‘lmadi</p>`;
    }
}
</script>

    <script>
        // Lavozimlarni yuklash
        loadPositions();
        // Top 5 natijalarni yuklash
        loadTopResults();
    </script>
</body>
</html>
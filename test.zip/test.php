<?php require_once 'config.php'; ?>
<!DOCTYPE html>
<html lang="uz">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Test Topshirish - By Dr.Qurbonov</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <div class="container">
        <div class="header">
            <h1>📝 Test Topshirish</h1>
            <div id="userInfo" class="user-info"></div>
        </div>

        <div class="test-container" id="testContainer">
            <div class="test-progress">
                <div class="progress-bar">
                    <div class="progress-fill" id="progressBar"></div>
                </div>
                <div class="progress-text">
                    Savol <span id="currentQuestion">1</span> / <span id="totalQuestions">0</span>
                </div>
                <div class="timer" id="timer">⏱️ 00:00</div>
            </div>

            <div class="question-box" id="questionBox">
                <div class="question-text" id="questionText"></div>
                <div class="options" id="optionsContainer"></div>
            </div>

            <div class="test-navigation">
                <button id="prevBtn" class="btn btn-secondary" style="display:none;">⬅️ Orqaga</button>
                <button id="nextBtn" class="btn btn-primary">Keyingisi ➡️</button>
                <button id="finishBtn" class="btn btn-success" style="display:none;">✅ Yakunlash</button>
            </div>
        </div>

        <div class="result-container" id="resultContainer" style="display:none;">
            <div class="result-box">
                <h2 id="resultTitle"></h2>
                <div class="result-score" id="resultScore"></div>
                <div class="result-details" id="resultDetails"></div>
                <div class="result-actions">
                    <button onclick="showAnalysis()" class="btn btn-primary" id="analysisBtn">
                        📊 Tahlil ko'rish
                    </button>
                    <button onclick="location.href='index.php'" class="btn btn-secondary">
                        🏠 Bosh sahifa
                    </button>
                    <button onclick="window.print()" class="btn btn-secondary">
                        🖨️ Natijani chop etish
                    </button>
                    <button onclick="shareResult()" class="btn btn-success" id="shareBtn">
                        🔗 Natijani ulashish
                    </button>
                </div>
                <div id="shareLink" style="display:none; margin-top: 20px; text-align: center;">
                    <p style="font-weight: 600; color: #667eea;">Ulashish havolasi:</p>
                    <input type="text" id="shareLinkInput" readonly style="width: 100%; padding: 10px; border: 2px solid #667eea; border-radius: 8px; text-align: center; font-size: 0.9em;">
                    <button onclick="copyShareLink()" class="btn btn-primary" style="margin-top: 10px;">
                        📋 Nusxa olish
                    </button>
                </div>
            </div>
        </div>

        <!-- Tahlil container -->
        <div class="analysis-container" id="analysisContainer" style="display:none;">
            <div class="analysis-header">
                <h2>📊 Test Tahlili</h2>
                <button onclick="hideAnalysis()" class="btn btn-secondary">⬅️ Natijaga qaytish</button>
            </div>
            <div class="analysis-content" id="analysisContent"></div>
        </div>
        <div class="footer">
            <p>&copy; Production by Dr.QURBONOV 2025</p>
        </div>
    </div>

    <script src="script.js"></script>
    
    <script>
    async function initTest() {
    const testData = JSON.parse(sessionStorage.getItem('testData'));
    
    if (!testData) {
        window.location.href = 'index.php';
        return;
    }
    
    currentTest.fullname = testData.fullname;
    currentTest.position = testData.position;
    
    // Foydalanuvchi ma'lumotlarini ko'rsatish
    const userInfo = document.getElementById('userInfo');
    if (userInfo) {
        userInfo.innerHTML = `
            <strong>👤 ${currentTest.fullname}</strong> | 
            <strong>💼 ${currentTest.position.nomi}</strong>
        `;
    }
    
    // Savollarni yuklash
    try {
        let response;
        if (currentTest.position.id === 'all') {
            // Barcha savollarni yuklash
            response = await fetch(`api.php?action=get_all_questions`);
            let allQuestions = await response.json();
            
            // Random tartibda chiqarish
            allQuestions = allQuestions.sort(() => Math.random() - 0.5);
            
            // Har bir savolning variantlarini aralashtirish
            currentTest.questions = allQuestions.map(question => {
                const options = [
                    {key: 'a', text: question.variant_a},
                    {key: 'b', text: question.variant_b},
                    {key: 'c', text: question.variant_c},
                    {key: 'd', text: question.variant_d}
                ];
                // Options ni random qilish
                const shuffled = options.sort(() => Math.random() - 0.5);
                return {...question, options: shuffled};
            });
        } else {
            // Bir lavozim uchun savollar
            response = await fetch(`api.php?action=get_questions&position_id=${currentTest.position.id}`);
            currentTest.questions = await response.json();
        }
        
        if (currentTest.questions.length === 0) {
            alert('Savollar topilmadi!');
            window.location.href = 'index.php';
            return;
        }
        
        // Javoblar massivini yaratish
        currentTest.answers = new Array(currentTest.questions.length).fill(null);
        currentTest.startTime = new Date();
        
        // Timer boshlash
        startTimer();
        
        // Birinchi savolni ko'rsatish
        showQuestion(0);
        
    } catch (error) {
        console.error('Xatolik:', error);
        alert('Savollarni yuklashda xatolik yuz berdi!');
        window.location.href = 'index.php';
    }
}
        // Test ni boshlash
        initTest();
    </script>
</body>
</html>